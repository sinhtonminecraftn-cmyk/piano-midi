# Piano MIDI (Android)

Quét màn hình điện thoại -> nhận diện nốt piano (video kiểu nốt rơi / Synthesia) -> xuất file .mid

## Build
1. Cài Android Studio (bản mới), chọn File > Open > thư mục PianoMidiAndroid.
2. Đợi Gradle sync (nếu hỏi phiên bản Gradle: chọn 8.7 trở lên).
3. Cắm điện thoại (bật Gỡ lỗi USB) rồi bấm Run, hoặc Build > Build APK(s).

## Cách dùng
1. Mở YouTube, tạm dừng video sao cho thấy rõ cả bàn phím.
2. Mở app Piano MIDI, chọn loại đàn (hoặc để Tự động), bấm "Bắt đầu quét màn hình".
3. Android 14+: chọn "Một ứng dụng" rồi chọn YouTube để chỉ quét app đó.
4. Quay lại YouTube, đợi thông báo "Đã khóa bàn phím" trong app, rồi bấm phát video.
5. Xong bấm "Dừng" trong thông báo (hoặc trong app), mở lại app và chọn nơi lưu file .mid.
