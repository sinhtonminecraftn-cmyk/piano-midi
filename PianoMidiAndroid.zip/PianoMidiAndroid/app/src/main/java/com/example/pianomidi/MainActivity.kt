package com.example.pianomidi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        const val REQ_CAPTURE = 1
        const val REQ_SAVE = 2
        const val REQ_NOTIF = 3
    }

    private lateinit var spPreset: Spinner
    private lateinit var seek: SeekBar
    private lateinit var tvThr: TextView
    private lateinit var cbSkin: CheckBox
    private lateinit var cbBars: CheckBox
    private lateinit var etSpeed: EditText
    private lateinit var tvStatus: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var askedSave = true

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setPadding(0, dp(12), 0, dp(2))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }
        root.addView(TextView(this).apply { text = "Piano → MIDI"; textSize = 22f })

        root.addView(label("Loại đàn"))
        spPreset = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                Presets.names
            )
        }
        root.addView(spPreset)

        tvThr = label("Độ nhạy (ngưỡng màu): 45")
        root.addView(tvThr)
        seek = SeekBar(this).apply {
            max = 105
            progress = 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    tvThr.text = "Độ nhạy (ngưỡng màu): ${p + 15}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(seek)

        cbSkin = CheckBox(this).apply { text = "Bỏ qua tay người (màu da)"; isChecked = true }
        cbBars = CheckBox(this).apply { text = "Dùng cả nốt đang rơi sát bàn phím"; isChecked = true }
        root.addView(cbSkin)
        root.addView(cbBars)

        root.addView(label("Tốc độ phát video (0.5 = chậm một nửa)"))
        etSpeed = EditText(this).apply { setText("1.0") }
        root.addView(etSpeed)

        val btnStart = Button(this).apply { text = "Bắt đầu quét màn hình" }
        val btnStop = Button(this).apply { text = "Dừng & xuất MIDI" }
        root.addView(btnStart)
        root.addView(btnStop)

        tvStatus = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(16), 0, 0)
            text = Session.status
        }
        root.addView(tvStatus)

        setContentView(ScrollView(this).apply { addView(root) })

        btnStart.setOnClickListener { startCapture() }
        btnStop.setOnClickListener {
            startService(
                Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)
            )
        }
    }

    private fun startCapture() {
        if (Session.running) {
            Toast.makeText(this, "Đang chạy rồi.", Toast.LENGTH_SHORT).show()
            return
        }
        Session.preset = spPreset.selectedItemPosition
        Session.thr = seek.progress + 15
        Session.skin = cbSkin.isChecked
        Session.bars = cbBars.isChecked
        Session.speed = etSpeed.text.toString().replace(',', '.').toFloatOrNull() ?: 1f

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                askedSave = false
                val i = Intent(this, CaptureService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                Toast.makeText(
                    this,
                    "Mở YouTube, để thấy bàn phím, đợi app khóa bàn phím rồi bấm phát.",
                    Toast.LENGTH_LONG
                ).show()
                moveTaskToBack(true)
            }
        } else if (requestCode == REQ_SAVE) {
            val uri = data?.data
            val notes = Session.result
            if (resultCode == RESULT_OK && uri != null && notes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(MidiWriter.write(notes)) }
                    Session.status = "Đã lưu ${notes.size} nốt vào file MIDI."
                } catch (e: Exception) {
                    Session.status = "Lỗi lưu file: ${e.message}"
                }
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            tvStatus.text = Session.status
            val r = Session.result
            if (r != null && !askedSave) {
                askedSave = true
                if (r.isEmpty()) {
                    Toast.makeText(
                        this@MainActivity,
                        "Không nhận diện được nốt nào. Thử chỉnh độ nhạy hoặc chọn loại đàn.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                        .addCategory(Intent.CATEGORY_OPENABLE)
                        .setType("audio/midi")
                        .putExtra(Intent.EXTRA_TITLE, "output.mid")
                    @Suppress("DEPRECATION")
                    startActivityForResult(i, REQ_SAVE)
                }
            }
            ui.postDelayed(this, 300)
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }
}
