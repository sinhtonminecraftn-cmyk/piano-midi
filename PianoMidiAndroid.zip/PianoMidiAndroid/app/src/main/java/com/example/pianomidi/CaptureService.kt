package com.example.pianomidi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Display
import kotlin.math.abs

class CaptureService : Service() {
    companion object {
        const val ACTION_STOP = "com.example.pianomidi.STOP"
        private const val CHANNEL = "cap"
        private const val NOTIF_ID = 1
    }

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null

    private var detector: PianoDetector? = null
    private var candidate: Keyboard? = null
    private var stable = 0
    private var frameCount = 0
    private var t0 = -1L
    private var lastT = 0.0
    private var finished = false
    private val accNotes = ArrayList<Note>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("capture").also { it.start() }
        handler = Handler(thread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (!Session.running) {
                stopSelf()
            } else {
                finalizeAndStop()
            }
            return START_NOT_STICKY
        }
        if (intent == null || Session.running) return START_NOT_STICKY

        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("data")
        }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Android 14: phải gọi startForeground trước khi getMediaProjection
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }

        Session.running = true
        Session.result = null
        Session.status = "Đang tìm bàn phím... Hãy để bàn phím hiện rõ trên màn hình."

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                finalizeAndStop()
            }
        }, handler)
        handler.post { setupDisplay() }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Piano MIDI", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Đang nhận diện piano")
            .setContentText("Bấm Dừng để kết thúc, rồi mở app để lưu MIDI")
            .addAction(android.R.drawable.ic_media_pause, "Dừng", stop)
            .setOngoing(true)
            .build()
    }

    private fun setupDisplay() {
        val p = projection ?: return
        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val s = minOf(1f, 1600f / maxOf(dm.widthPixels, dm.heightPixels))
        val w = (dm.widthPixels * s).toInt() and 1.inv()
        val h = (dm.heightPixels * s).toInt() and 1.inv()

        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, handler)
        reader = r

        val d = vd
        if (d == null) {
            vd = p.createVirtualDisplay(
                "pianomidi", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
        } else {
            d.resize(w, h, dm.densityDpi)
            d.surface = r.surface
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!Session.running || finished) return
        // Xoay màn hình: giữ nốt đã ghi, tìm lại bàn phím, thời gian vẫn chạy tiếp
        handler.post {
            detector?.let { accNotes += it.finish(lastT) }
            detector = null
            candidate = null
            stable = 0
            Session.status = "Đã xoay màn hình, đang tìm lại bàn phím..."
            setupDisplay()
        }
    }

    private fun onFrame(rd: ImageReader) {
        val img = rd.acquireLatestImage() ?: return
        try {
            if (finished) return
            val plane = img.planes[0]
            val f = Frame(img.width, img.height, plane.buffer, plane.rowStride)
            val ts = if (img.timestamp != 0L) img.timestamp else System.nanoTime()
            if (t0 < 0) t0 = ts
            val t = (ts - t0) / 1e9 * Session.speed
            lastT = t

            val det = detector
            if (det == null) {
                tryLock(f)
                return
            }
            det.process(f, t)
            frameCount++
            if (frameCount % 20 == 0) {
                Session.status = "Đang ghi... %.1fs".format(t)
            }
        } finally {
            img.close()
        }
    }

    private fun tryLock(f: Frame) {
        frameCount++
        if (frameCount % 8 != 0) return
        val kb = KeyboardFinder.find(f)
        val c = candidate
        if (kb != null && c != null &&
            abs(kb.top - c.top) <= 4 && abs(kb.bot - c.bot) <= 4 &&
            abs(kb.xl - c.xl) <= 4 && abs(kb.xr - c.xr) <= 4
        ) {
            stable++
        } else {
            stable = if (kb != null) 1 else 0
        }
        candidate = kb
        if (kb != null && stable >= 3) {
            val preset = if (Session.preset == 0) KeyboardFinder.guessPreset(f, kb) else Session.preset
            detector = PianoDetector(
                kb, preset, Session.thr.toFloat(), Session.bars, Session.skin
            )
            Session.status = "Đã khóa bàn phím (${Presets.names[preset]}). Hãy bấm phát video."
        } else {
            Session.status = "Đang tìm bàn phím... Hãy để bàn phím hiện rõ trên màn hình."
        }
    }

    private fun finalizeAndStop() {
        handler.post {
            if (finished) return@post
            finished = true
            detector?.let { accNotes += it.finish(lastT) }
            val res = accNotes.sortedBy { it.start }
            Session.result = res
            Session.running = false
            Session.status = "Đã dừng. Nhận diện được ${res.size} nốt. Mở app để lưu file MIDI."
            try { vd?.release() } catch (_: Exception) {}
            try { reader?.close() } catch (_: Exception) {}
            try { projection?.stop() } catch (_: Exception) {}
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            thread.quitSafely()
        }
    }
}
