package com.example.pianomidi

import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max

/** Khung hình RGBA_8888 từ ImageReader. */
class Frame(val w: Int, val h: Int, private val buf: ByteBuffer, private val rowStride: Int) {
    fun r(x: Int, y: Int) = buf.get(y * rowStride + x * 4).toInt() and 255
    fun g(x: Int, y: Int) = buf.get(y * rowStride + x * 4 + 1).toInt() and 255
    fun b(x: Int, y: Int) = buf.get(y * rowStride + x * 4 + 2).toInt() and 255
}

data class Note(val midi: Int, val start: Double, val end: Double)
data class Keyboard(val top: Int, val bot: Int, val xl: Int, val xr: Int)

/** Trạng thái dùng chung giữa Activity và Service. */
object Session {
    @Volatile var status: String = "Chưa chạy."
    @Volatile var running: Boolean = false
    @Volatile var result: List<Note>? = null
    @Volatile var preset: Int = 0
    @Volatile var thr: Int = 45
    @Volatile var skin: Boolean = true
    @Volatile var bars: Boolean = true
    @Volatile var speed: Float = 1f
}

object Presets {
    // index 0 = tự động
    val names = listOf(
        "Tự động", "88 phím (A0-C8)", "76 phím (E1-G7)",
        "61 phím (C2-C7)", "49 phím (C2-C6)", "37 phím (C3-C6)"
    )
    val ranges = listOf(0 to 0, 21 to 108, 28 to 103, 36 to 96, 36 to 84, 48 to 84)
    private val white = setOf(0, 2, 4, 5, 7, 9, 11)
    fun isWhite(midi: Int) = midi % 12 in white
    fun countWhite(lo: Int, hi: Int) = (lo..hi).count { isWhite(it) }
}

object KeyboardFinder {
    private fun brightNeutral(r: Int, g: Int, b: Int): Boolean {
        val mx = max(r, max(g, b))
        val mn = minOf(r, minOf(g, b))
        return mx >= 170 && (mx - mn) <= 0.27f * mx
    }

    fun find(f: Frame): Keyboard? {
        val w = f.w
        val h = f.h
        val startY = (h * 0.25).toInt()
        val rows = BooleanArray(h)
        for (y in startY until h) {
            var cnt = 0
            var tot = 0
            var x = 0
            while (x < w) {
                if (brightNeutral(f.r(x, y), f.g(x, y), f.b(x, y))) cnt++
                tot++
                x += 4
            }
            rows[y] = cnt.toFloat() / tot > 0.35f
        }
        var bestS = -1
        var bestE = -1
        var y = startY
        while (y < h) {
            if (rows[y]) {
                var j = y
                while (j < h && rows[j]) j++
                if (bestS < 0 || j - y > bestE - bestS) {
                    bestS = y; bestE = j
                }
                y = j
            } else y++
        }
        if (bestS < 0 || bestE - bestS < h * 0.04) return null
        val top = bestS
        val bot = bestE
        val kh = bot - top
        val y0 = bot - max(3, (kh * 0.2).toInt())
        val y1 = max(y0 + 1, bot - 1)
        var xl = -1
        var xr = -1
        for (x in 0 until w) {
            var c = 0
            var t = 0
            for (yy in y0 until y1) {
                if (brightNeutral(f.r(x, yy), f.g(x, yy), f.b(x, yy))) c++
                t++
            }
            if (t > 0 && c.toFloat() / t > 0.5f) {
                if (xl < 0) xl = x
                xr = x + 1
            }
        }
        if (xl < 0 || xr - xl < w * 0.3) return null
        return Keyboard(top, bot, xl, xr)
    }

    /** Đếm đường kẻ giữa phím trắng để đoán loại đàn (trả về chỉ số 1..5). */
    fun guessPreset(f: Frame, kb: Keyboard): Int {
        val kh = kb.bot - kb.top
        val y0 = kb.bot - max(3, (kh * 0.2).toInt())
        val y1 = max(y0 + 1, kb.bot - 1)
        val n = kb.xr - kb.xl
        val prof = FloatArray(n) { i ->
            var s = 0f
            for (y in y0 until y1) {
                val x = kb.xl + i
                s += 0.299f * f.r(x, y) + 0.587f * f.g(x, y) + 0.114f * f.b(x, y)
            }
            s / (y1 - y0)
        }
        val med = prof.sortedArray()[n / 2]
        val runs = ArrayList<Int>()
        var i = 0
        while (i < n) {
            if (prof[i] < med * 0.94f) {
                var j = i
                while (j < n && prof[j] < med * 0.94f) j++
                runs.add(j - i)
                i = j
            } else i++
        }
        var best = 1
        var bestErr = Int.MAX_VALUE
        for (p in 1 until Presets.ranges.size) {
            val (lo, hi) = Presets.ranges[p]
            val nw = Presets.countWhite(lo, hi)
            val ww = n.toFloat() / nw
            val cnt = runs.count { it <= 0.35f * ww }
            val err = abs(cnt - (nw - 1))
            if (err < bestErr) {
                bestErr = err; best = p
            }
        }
        return best
    }
}

class PianoDetector(
    kb: Keyboard,
    presetIdx: Int,
    private val thrOn: Float,
    private val useBars: Boolean,
    private val skipSkin: Boolean,
    private val minLen: Double = 0.03
) {
    private class Patch(
        val kx0: Int, val kx1: Int, val ky0: Int, val ky1: Int,
        val bx0: Int, val bx1: Int, val by0: Int, val by1: Int
    )

    private val midi: IntArray
    private val patches: Array<Patch>
    private val thrOff = thrOn * 0.6f
    private val on: BooleanArray
    private val startT: DoubleArray
    private val notes = ArrayList<Note>()
    private val tmp = IntArray(9)
    private var skinFrac = 0f

    init {
        val (lo, hi) = Presets.ranges[presetIdx]
        val nw = Presets.countWhite(lo, hi)
        val ww = (kb.xr - kb.xl).toFloat() / nw
        val kh = kb.bot - kb.top
        val list = ArrayList<Int>()
        val ps = ArrayList<Patch>()
        var wi = 0
        for (n in lo..hi) {
            val white = Presets.isWhite(n)
            val cx: Int
            val kx: Int
            val ky0: Int
            val ky1: Int
            val bx: Int
            if (white) {
                cx = (kb.xl + (wi + 0.5f) * ww).toInt()
                wi++
                kx = max(1, (ww * 0.25f).toInt())
                ky0 = kb.bot - (kh * 0.22f).toInt()
                ky1 = kb.bot - (kh * 0.06f).toInt()
                bx = kx
            } else {
                cx = (kb.xl + wi * ww).toInt()
                kx = max(1, (ww * 0.17f).toInt())
                ky0 = kb.top + (kh * 0.12f).toInt()
                ky1 = kb.top + (kh * 0.40f).toInt()
                bx = max(1, (ww * 0.12f).toInt())
            }
            val by0 = kb.top - max(2, (kh * 0.08f).toInt())
            val by1 = kb.top - max(1, (kh * 0.03f).toInt())
            list.add(n)
            ps.add(Patch(cx - kx, cx + kx, ky0, ky1, cx - bx, cx + bx, by0, by1))
        }
        midi = list.toIntArray()
        patches = ps.toTypedArray()
        on = BooleanArray(midi.size)
        startT = DoubleArray(midi.size)
    }

    private fun isSkin(r: Int, g: Int, b: Int): Boolean {
        val y = 0.299f * r + 0.587f * g + 0.114f * b
        val cr = (r - y) * 0.713f + 128f
        val cb = (b - y) * 0.564f + 128f
        return cr in 138f..173f && cb in 77f..127f
    }

    /** Lấy mẫu lưới 3x3, trả về độ "màu" (max-min) trung vị; cập nhật skinFrac. */
    private fun sample(f: Frame, x0: Int, x1: Int, y0: Int, y1: Int): Int {
        val xs = intArrayOf(x0, (x0 + x1) / 2, max(x0, x1 - 1))
        val ys = intArrayOf(y0, (y0 + y1) / 2, max(y0, y1 - 1))
        var n = 0
        var skin = 0
        for (y in ys) for (x in xs) {
            val cx = x.coerceIn(0, f.w - 1)
            val cy = y.coerceIn(0, f.h - 1)
            val r = f.r(cx, cy)
            val g = f.g(cx, cy)
            val b = f.b(cx, cy)
            tmp[n++] = max(r, max(g, b)) - minOf(r, minOf(g, b))
            if (skipSkin && isSkin(r, g, b)) skin++
        }
        skinFrac = skin / 9f
        tmp.sort()
        return tmp[4]
    }

    private fun end(i: Int, t: Double) {
        if (t - startT[i] >= minLen) notes.add(Note(midi[i], startT[i], t))
        on[i] = false
    }

    fun process(f: Frame, t: Double) {
        for (i in patches.indices) {
            val p = patches[i]
            var sc = 0f
            var unknown = false
            val kc = sample(f, p.kx0, p.kx1, p.ky0, p.ky1)
            if (skinFrac > 0.5f) unknown = true else sc = kc.toFloat()
            if (useBars) {
                val bc = sample(f, p.bx0, p.bx1, p.by0, p.by1)
                if (skinFrac <= 0.5f) {
                    sc = max(sc, bc.toFloat())
                    if (sc > thrOn) unknown = false
                }
            }
            if (unknown && sc <= thrOn) continue // tay che phím: giữ trạng thái cũ
            if (!on[i]) {
                if (sc > thrOn) {
                    on[i] = true
                    startT[i] = t
                }
            } else if (sc < thrOff) {
                end(i, t)
            }
        }
    }

    fun finish(t: Double): List<Note> {
        for (i in on.indices) if (on[i]) end(i, t)
        return notes.sortedBy { it.start }
    }
}
