package com.example.pianomidi

import java.io.ByteArrayOutputStream

object MidiWriter {
    private fun varLen(value: Int, o: ByteArrayOutputStream) {
        var v = value
        val stack = IntArray(5)
        var n = 0
        stack[n++] = v and 0x7F
        v = v ushr 7
        while (v > 0) {
            stack[n++] = (v and 0x7F) or 0x80
            v = v ushr 7
        }
        while (n > 0) o.write(stack[--n])
    }

    /** 480 tick/beat, 120 BPM => 1 giây = 960 tick. */
    fun write(notes: List<Note>): ByteArray {
        // (tick, type, note): type 0 = off, 1 = on -> off xếp trước on cùng tick
        val ev = ArrayList<Triple<Int, Int, Int>>()
        for (n in notes) {
            val ts = Math.round(n.start * 960).toInt()
            val te = maxOf(ts + 1, Math.round(n.end * 960).toInt())
            ev.add(Triple(ts, 1, n.midi))
            ev.add(Triple(te, 0, n.midi))
        }
        ev.sortWith(compareBy({ it.first }, { it.second }))

        val tr = ByteArrayOutputStream()
        tr.write(byteArrayOf(0x00, 0xFF.toByte(), 0x51, 0x03, 0x07, 0xA1.toByte(), 0x20))
        var last = 0
        for ((tick, typ, note) in ev) {
            varLen(tick - last, tr)
            tr.write(if (typ == 1) 0x90 else 0x80)
            tr.write(note)
            tr.write(if (typ == 1) 90 else 0)
            last = tick
        }
        tr.write(byteArrayOf(0x00, 0xFF.toByte(), 0x2F, 0x00))

        val out = ByteArrayOutputStream()
        out.write("MThd".toByteArray())
        out.write(byteArrayOf(0, 0, 0, 6, 0, 0, 0, 1, 0x01, 0xE0.toByte()))
        out.write("MTrk".toByteArray())
        val len = tr.size()
        out.write(
            byteArrayOf(
                (len ushr 24).toByte(), (len ushr 16).toByte(),
                (len ushr 8).toByte(), len.toByte()
            )
        )
        out.write(tr.toByteArray())
        return out.toByteArray()
    }
}
